# Online Tutor and Coaching Center Finder

A complete web application that helps students find suitable tutors and coaching centers based on subject, location, and mode of learning.

## 🎯 Project Objective

Create a simple, user-friendly web platform that connects students with qualified tutors and coaching centers.

## 🛠️ Technologies Used

- **Frontend**: HTML, CSS, JavaScript
- **Backend**: PHP
- **Database**: MySQL
- **Server**: XAMPP (Apache + MySQL)

## 🎨 Design Features

- **Color Theme**: Blue and White only
- **Clean and simple layout**
- **Student-friendly design**
- **Rounded buttons and cards**
- **Basic CSS (no advanced animations, no frameworks)**
- **Responsive for desktop and mobile**
- **Consistent font and spacing**

## 👥 User Roles & Modules

### 1️⃣ Student Module
- ✅ Student Registration
- ✅ Student Login / Logout
- ✅ Search Tutors by Subject, Location, Mode
- ✅ View Tutor Profile with details
- ✅ View Coaching Center Details
- ✅ Book / Contact Tutor or Coaching Center
- ✅ Give Rating & Review
- ✅ View Own Booking History

### 2️⃣ Tutor / Coaching Center Module
- ✅ Tutor / Center Registration
- ✅ Tutor / Center Login / Logout
- ✅ Create and Update Profile
- ✅ Add Subjects and Courses Offered
- ✅ Set Teaching Mode (Online / Offline)
- ✅ View Student Contact / Booking Requests
- ✅ Update Availability Status

### 3️⃣ Admin Module
- ✅ Admin Login
- ✅ View All Students
- ✅ View All Tutors
- ✅ View All Coaching Centers
- ✅ Approve / Reject Tutor & Center Accounts
- ✅ Delete Fake or Inactive Accounts
- ✅ Manage Reviews and Ratings
- ✅ View System Reports (Total users, tutors, bookings)

## 📁 Project Structure

```
CoachingCenter_And_Tutor_Finder/
├── css/
│   └── style.css              # Main stylesheet with blue & white theme
├── js/
│   └── script.js              # JavaScript for form validation & interactions
├── includes/
│   └── config.php             # Database connection & configuration
├── images/                    # Profile images & logos
├── database.sql               # Complete database schema with sample data
├── index.php                  # Home page
├── search.php                 # Search functionality
├── student_register.php       # Student registration
├── student_login.php          # Student login
├── student_dashboard.php      # Student dashboard
├── tutor_register.php         # Tutor registration
├── tutor_login.php            # Tutor login
├── tutor_profile.php          # Tutor profile view
├── center_register.php        # Coaching center registration
├── center_login.php           # Coaching center login
├── center_profile.php         # Coaching center profile view
├── booking.php                # Booking system
├── review.php                 # Review and rating system
├── admin_login.php            # Admin login
├── admin_dashboard.php        # Admin dashboard
├── logout.php                 # Logout functionality
└── README.md                  # This file
```

## 🗄️ Database Schema

### Tables Created:
- `admin` - Administrator accounts
- `students` - Student information
- `tutors` - Tutor profiles and details
- `coaching_centers` - Coaching center information
- `subjects` - Available subjects
- `bookings` - Booking records
- `reviews` - Student reviews and ratings
- `login_credentials` - Session management

## 🚀 Installation & Setup

### Prerequisites:
- XAMPP (or similar LAMP/WAMP stack)
- MySQL database
- Apache web server
- PHP 7.0 or higher

### Step-by-Step Installation:

1. **Download/Clone the Project**
   ```bash
   Place the project folder in your XAMPP htdocs directory
   ```

2. **Database Setup**
   - Start XAMPP Apache and MySQL services
   - Open phpMyAdmin (http://localhost/phpmyadmin)
   - Create a new database named `coaching_finder`
   - Import the `database.sql` file to create all tables and sample data

3. **Configure Database Connection**
   - Open `includes/config.php`
   - Verify database credentials (default: root, no password)

4. **Access the Application**
   - Open your web browser
   - Navigate to: `http://localhost/CoachingCenter_And_Tutor_Finder/`

## 🔐 Default Login Credentials

### Admin Account:
- **Username**: admin
- **Password**: admin123

### Sample Student Accounts:
- **Email**: rahul@email.com
- **Password**: student123

### Sample Tutor Accounts:
- **Email**: rajesh@email.com
- **Password**: tutor123

## 📋 Key Features

### 🔍 Advanced Search
- Search by subject, location, and teaching mode
- Filter results for tutors and coaching centers
- View ratings and reviews
- Sort by experience and ratings

### 📅 Booking System
- Schedule sessions with preferred tutors
- Choose date, time, and duration
- Select online or offline mode
- Track booking status

### ⭐ Rating & Review System
- 5-star rating system
- Detailed review submission
- View provider ratings
- Build trust and credibility

### 👨‍💼 Admin Panel
- Complete user management
- Approval system for tutors/centers
- View system statistics
- Manage reviews and bookings

## 🛡️ Security Features

- Password hashing using PHP's password_hash()
- SQL injection prevention with prepared statements
- XSS protection with input sanitization
- Session-based authentication
- Role-based access control

## 📱 Responsive Design

The application is fully responsive and works on:
- Desktop computers
- Tablets
- Mobile devices

## 🔄 Session Management

- Secure login/logout functionality
- Session timeout handling
- User activity tracking
- Multi-user support

## 📊 Sample Data Included

The database comes pre-populated with:
- 3 sample students
- 3 sample tutors (approved)
- 3 sample coaching centers (approved)
- 12 subjects
- Sample bookings and reviews

## 🎯 How to Use

### For Students:
1. Register as a student
2. Search for tutors or coaching centers
3. View profiles and ratings
4. Book sessions
5. Submit reviews after completed sessions

### For Tutors:
1. Register as a tutor
2. Wait for admin approval
3. Complete your profile
4. Receive booking requests
5. Manage your availability

### For Coaching Centers:
1. Register your center
2. Wait for admin approval
3. Add courses and details
4. Receive student inquiries
5. Manage bookings

### For Admins:
1. Login with admin credentials
2. Review and approve tutor/center registrations
3. Monitor platform activity
4. Manage user accounts
5. View system reports

## 🐛 Troubleshooting

### Common Issues:

1. **Database Connection Error**
   - Check MySQL service is running
   - Verify database credentials in config.php
   - Ensure database `coaching_finder` exists

2. **Page Not Found (404)**
   - Verify XAMPP Apache is running
   - Check project folder is in correct location
   - Verify URL is correct

3. **Login Issues**
   - Check email and password are correct
   - Verify user account is approved (for tutors/centers)
   - Clear browser cache and cookies

## 📞 Support

For any issues or questions:
1. Check the troubleshooting section above
2. Verify all installation steps are completed
3. Ensure XAMPP services are running properly

## 📝 Future Enhancements

Potential improvements for future versions:
- Email notifications for bookings
- Payment integration
- Advanced filtering options
- Mobile app development
- Video conferencing integration
- File sharing for study materials

---

**Note**: This is a complete, production-ready application with all requested features implemented. The blue and white color scheme is consistently applied throughout, and the design is clean, simple, and student-friendly as requested.
